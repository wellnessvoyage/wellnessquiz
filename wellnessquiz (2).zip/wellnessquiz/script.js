document.addEventListener('DOMContentLoaded', () => {
    const startButton = document.getElementById('start-button');
    const nextButton = document.getElementById('next-button');
    const replayButton = document.getElementById('replay-button');

    const startScreen = document.querySelector('.start-screen');
    const quizScreen = document.querySelector('.quiz-screen');
    const resultScreen = document.querySelector('.result-screen');

    const questionContainer = document.getElementById('question-container');
    const pieChartContainer = document.getElementById('pie-chart');
    const remarksContainer = document.getElementById('remarks');
    const scoreDisplayContainer = document.getElementById('score-display');

    const questions = [
        {
            question: "How are you feeling TODAY?",
            options: ["Cheerful", "Lonely", "Just Fine", "Depressed"],
            scores: [2, 1, 1.5, 0.5]
        },
        {
            question: "Things/People you are Grateful for",
            options: ["Family and Friends", "Something Great happened Today", "To yourself", "Something else"],
            scores: [2, 1, 1, 1]
        },
        {
            question: "How has your mood been since last 15 days? Rate it on a scale of 0-5",
            options: ["5", "3-4", "1-2", "0"],
            scores: [2, 1.5, 1, 0.5]
        },
        {
            question: "What things are you stressed about right now?",
            options: ["I don't have any stress", "Studies/Work", "Family issues", "Something else"],
            scores: [2, 1.5, 1, 0.5]
        },
        {
            question: "What is usually the issue of your Bad mood?",
            options: ["I usually don't have a bad mood", "Family issues", "Under confident about yourself", "People don't understand you", "Something else"],
            scores: [2, 1, 1, 1.5, 0.5]
        }
    ];

    let currentQuestionIndex = 0;
    let totalScore = 0;

    function showQuestion(index) {
        const question = questions[index];
        questionContainer.innerHTML = `
            <p>${question.question}</p>
            ${question.options.map((option, i) => `
                <label>
                    <input type="radio" name="answer" value="${question.scores[i]}">
                    ${option}
                </label>
            `).join('')}
        `;
    }

    function calculateScore() {
        const selectedAnswer = document.querySelector('input[name="answer"]:checked');
        if (selectedAnswer) {
            const selectedOption = parseFloat(selectedAnswer.value);
            totalScore += selectedOption;
        }
    }

    function displayResults() {
        pieChartContainer.innerHTML = ''; // Clear previous chart
        const canvas = document.createElement('canvas');
        pieChartContainer.appendChild(canvas);
        const ctx = canvas.getContext('2d');

        const maxScore = 10;
        new Chart(ctx, {
            type: 'pie',
            data: {
                labels: ['Score', 'Remaining'],
                datasets: [{
                    data: [totalScore, maxScore - totalScore],
                    backgroundColor: ['#FFD700', '#FFB6C1'], // Yellow and Baby Pink
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false
            }
        });
        pieChartContainer.parentNode.style.height = '200px'; // Set the height of the pie chart container to make it smaller

        scoreDisplayContainer.textContent = `Your Score: ${totalScore}`;

        let message = "";
        if (totalScore === 10) {
            message = "WOW! YOU ARE GOING GREAT";
        } else if (totalScore >= 7 && totalScore <= 9.5) {
            message = "VERY GOOD";
        } else if (totalScore >= 5.5 && totalScore <= 6.5) {
            message = "GOOD";
        } else if (totalScore >= 1 && totalScore <= 5) {
            message = "YOU REALLY NEED HELP, BUT NOTHING TO WORRY WELLNESS VOYAGE IS WITH YOU";
        }
        remarksContainer.innerHTML += `<p><strong>${message}</strong></p>`;
    }

    startButton.addEventListener('click', () => {
        startScreen.style.display = 'none';
        quizScreen.style.display = 'block';
        showQuestion(currentQuestionIndex);
    });

    nextButton.addEventListener('click', () => {
        calculateScore();
        currentQuestionIndex++;
        if (currentQuestionIndex < questions.length) {
            showQuestion(currentQuestionIndex);
        } else {
            quizScreen.style.display = 'none';
            resultScreen.style.display = 'block';
            displayResults();
        }
    });

    replayButton.addEventListener('click', () => {
        resultScreen.style.display = 'none';
        quizScreen.style.display = 'block';
        currentQuestionIndex = 0;
        totalScore = 0;
        remarksContainer.innerHTML = ''; // Clear previous remarks
        showQuestion(currentQuestionIndex);
    });
});
